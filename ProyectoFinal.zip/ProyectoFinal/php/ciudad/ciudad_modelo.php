<?php
	require_once('../modeloAbstractoDB.php');
	class Ciudad extends ModeloAbstractoDB {
		private $ciu_codi;
		private $ciu_nomb;
		private $pais_codi;
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getciu_codi(){
			return $this->ciu_codi;
		}

		public function getciu_nomb(){
			return $this->ciu_nomb;
		}
		
		public function getPais_codi(){
			return $this->pais_codi;
		}                

		public function consultar($ciu_codi='') {
			if($ciu_codi != ''):
				$this->query = "
				SELECT ciu_codi, ciu_nomb, ciu_codi
				FROM tb_ciudades
				WHERE ciu_codi = '$ciu_codi'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT ciu_codi, ciu_nomb, p.pais_nomb
			FROM tb_ciudades as m inner join tb_paises as p
			ON (m.pais_codi = p.pais_codi) ORDER BY m.ciu_nomb
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		public function listadepartamento() {
			$this->query = "
			SELECT ciu_codi, ciu_nomb
			FROM tb_ciudades as d order by ciu_nomb
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		
		public function nuevo($datos=array()) {
			if(array_key_exists('ciu_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_ciudades
				(ciu_codi, ciu_nomb, pais_codi)
				VALUES
				('$ciu_codi', '$ciu_nomb', '$pais_codi')
				";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$this->query = "
			UPDATE tb_ciudades
			SET ciu_nomb='$ciu_nomb',
			pais_codi='$pais_codi'
			WHERE ciu_codi = '$ciu_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($ciu_codi='') {
			$this->query = "
			DELETE FROM tb_ciudades
			WHERE ciu_codi = '$ciu_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>