<?php
 
require_once 'propietarios_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $propietarios = new Propietarios();
        $resultado = $propietarios->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $propietarios = new Propietarios();
        $resultado = $propietarios->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
        $propietarios = new Propietarios();
        $resultado = $propietarios->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $propietarios = new Propietarios();
        $propietarios->consultar($datos['codigo']);

        if($propietarios->getpropi_codi() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $propietarios->getpropi_codi(),
                'propietarios' => $propietarios->getpropi_nomb(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $propietarios = new Propietarios();
        $listado = $propietarios->lista();        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;
}
?>
