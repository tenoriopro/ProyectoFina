<?php
	require_once('../modeloAbstractoDB.php');
	class Clientes extends ModeloAbstractoDB {
		private $clien_codi;
		private $clien_nomb;
		private $clien_ape;
		private $clien_tel;
		private $clien_email;
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getclien_codi(){
			return $this->clien_codi;
		}

		public function getclien_nomb(){
			return $this->clien_nomb;
		}

		public function getclien_ape(){
			return $this->clien_ape;
		}

		public function getclien_tel(){
			return $this->clien_tel;
		}

		public function getclien_email(){
			return $this->clien_email;
		}
		
          

		public function consultar($clien_codi='') {
			if($clien_codi != ''):
				$this->query = "
				SELECT clien_codi, clien_nomb, clien_ape, clien_tel, clien_email
				FROM tb_clientes
				WHERE clien_codi = '$clien_codi'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT clien_codi, clien_nomb, clien_ape, clien_tel, clien_email
			FROM tb_clientes as p ORDER BY p.clien_codi
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		public function listaPaises() {
			$this->query = "
			SELECT clien_codi, clien_nomb, clien_ape, clien_tel, clien_email
			FROM tb_clientes as p order by clien_nomb
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		
		public function nuevo($datos=array()) {
			if(array_key_exists('clien_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_clientes
				(clien_codi, clien_nomb, clien_ape, clien_tel, clien_email)
				VALUES
				('$clien_codi', '$clien_nomb', '$clien_ape', '$clien_tel','$clien_email')
				";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$this->query = "
			UPDATE tb_clientes
			SET clien_nomb='$clien_nomb',
			clien_ape='$clien_ape',
			clien_tel='$clien_tel',
			clien_email='$clien_email'
			WHERE clien_codi = '$clien_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($clien_codi='') {
			$this->query = "
			DELETE FROM tb_clientes
			WHERE clien_codi = '$clien_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>