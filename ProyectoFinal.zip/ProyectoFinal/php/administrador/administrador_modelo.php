<?php
	require_once('../modeloAbstractoDB.php');
	class Administradores extends ModeloAbstractoDB {
		private $admin_codi;
		private $admin_nomb;
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getadmin_codi(){
			return $this->admin_codi;
		}

		public function getadmin_nomb(){
			return $this->admin_nomb;
		}
		
          

		public function consultar($admin_codi='') {
			if($admin_codi != ''):
				$this->query = "
				SELECT admin_codi, admin_nomb
				FROM tb_administradores
				WHERE admin_codi = '$admin_codi'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT admin_codi, admin_nomb
			FROM tb_administradores as p ORDER BY p.admin_codi
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		public function listaPaises() {
			$this->query = "
			SELECT admin_codi, admin_nomb
			FROM tb_administradores as p order by admin_nomb
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		
		public function nuevo($datos=array()) {
			if(array_key_exists('admin_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_administradores
				(admin_codi, admin_nomb)
				VALUES
				('$admin_codi', '$admin_nomb')
				";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$this->query = "
			UPDATE tb_administradores
			SET admin_nomb='$admin_nomb'
			WHERE admin_codi = '$admin_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($admin_codi='') {
			$this->query = "
			DELETE FROM tb_administradores
			WHERE admin_codi = '$admin_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>