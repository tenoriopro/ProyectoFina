<?php
 
require_once 'administrador_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $administradores = new Administradores();
        $resultado = $administradores->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $administradores = new Administradores();
        $resultado = $administradores->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
        $administradores = new Administradores();
        $resultado = $administradores->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $administradores = new Administradores();
        $administradores->consultar($datos['codigo']);

        if($administradores->getadmin_codi() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $administradores->getadmin_codi(),
                'administradores' => $administradores->getadmin_nomb(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $administradores = new Administradores();
        $listado = $administradores->lista();        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;
}
?>
