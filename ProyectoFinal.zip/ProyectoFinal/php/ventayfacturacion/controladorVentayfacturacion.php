<?php
 
require_once 'Ventayfacturacion_modelo.php';
$datos = $_GET;

switch ($_GET['accion']){
    case 'editar':
        $venta = new Ventayfacturacion();
		$resultado = $venta->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $venta = new Ventayfacturacion();
		$resultado = $venta->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
		$venta = new Ventayfacturacion();
		$resultado = $venta->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $venta = new Ventayfacturacion();
        $venta->consultar($datos['codigo']);

        if($venta->getventa_codi() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $venta->getventa_codi(),
                'clientes' => $venta->getclien_codi(),
                'productos' =>$venta->getprodu_codi(),
                'cantidad' =>$venta->getprodu_cant(),
                'fecha' =>$venta->getfecha(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $venta = new Ventayfacturacion();
        $listado = $venta->lista();        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;
}
?>
