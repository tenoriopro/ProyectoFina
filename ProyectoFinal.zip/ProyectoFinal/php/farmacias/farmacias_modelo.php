<?php
	require_once('../modeloAbstractoDB.php');
	class farmacias extends ModeloAbstractoDB {
		private $farma_codi;
		private $farma_nomb;
		private $ciu_codi;
		private $admin_codi;
		private $propi_codi;
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getfarma_codi(){
			return $this->farma_codi;
		}

		public function getfarma_nomb(){
			return $this->farma_nomb;
		}
		
		public function getciu_codi(){
			return $this->ciu_codi;
		} 

		public function getadmin_codi(){
			return $this->admin_codi;
		}  

		public function getpropi_codi(){
			return $this->propi_codi;
		}                    

		public function consultar($farma_codi='') {
			if($farma_codi != ''):
				$this->query = "
				SELECT farma_codi, farma_nomb, ciu_codi, admin_codi, propi_codi
				FROM tb_farmacias
				WHERE farma_codi = '$farma_codi'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT farma_codi, farma_nomb, c.ciu_nomb, a.admin_nomb, p.propi_nomb 
			FROM tb_farmacias as f 
				inner join tb_ciudades as c 
				ON f.ciu_codi = c.ciu_codi
				inner join tb_administradores as a
				ON f.admin_codi = a.admin_codi
				inner join tb_propietarios as p
				ON f.propi_codi = p.propi_codi
				";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		public function listafarmacias() {
			$this->query = "
			SELECT farma_codi, farma_nomb
			FROM tb_farmacias as f order by farma_nomb
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		
		public function nuevo($datos=array()) {
			if(array_key_exists('farma_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_farmacias
					(farma_codi, farma_nomb, ciu_codi, admin_codi, propi_codi)
					VALUES
					(NULL, '$farma_nomb', '$ciu_codi', '$admin_codi', '$propi_codi')
					";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$this->query = "
			UPDATE tb_farmacias
			SET farma_nomb='$farma_nomb',
			ciu_codi='$ciu_codi',
			admin_codi='$admin_codi',
			propi_codi='$propi_codi'
			WHERE farma_codi = '$farma_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($farma_codi='') {
			$this->query = "
			DELETE FROM tb_farmacias
			WHERE farma_codi = '$farma_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>